package com.example.hellocd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JenkinsLab2Application {

	public static void main(String[] args) {
		SpringApplication.run(JenkinsLab2Application.class, args);
	}

}
